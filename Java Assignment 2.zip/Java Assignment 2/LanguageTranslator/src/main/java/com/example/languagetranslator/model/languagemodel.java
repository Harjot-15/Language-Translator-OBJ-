package com.example.languagetranslator.model;

public class languagemodel {
}
